--------------        -- 1)
select * from address;  
select * from city;
select * from country;
select * from staff;       

select 
     staff.staff_id,
     staff.first_name,
     staff.last_name,
     address.address,
     address.district,
     city.city,
     country.country
 from staff
 left join address
 on staff.address_id=address.address_id
 left join city
 on address.city_id=city.city_id
 left join country
 on city.country_id=country.country_id;
 
 ------------------  -- 2)
 
 select * from inventory;
 select * from film;
 
 select
      inventory.inventory_id,
      inventory.store_id,
      film.title as film_title,
      film.rating,
      film.rental_rate,
      film.replacement_cost
    from inventory  
   left join film
   on inventory.film_id=film.film_id;
   
  -----------------------   --3)
  select*from film;
  select * from inventory;
   select
      inventory.inventory_id,
      inventory.store_id,
      film.film_id,
      film.rating,
      film.rental_rate,
      film.replacement_cost
    from inventory  
   left join film
   on inventory.film_id=film.film_id
   group by inventory.store_id, film.rating
   order by count(inventory.inventory_id);
   
   ------------------------------  -- 4)
   select *from film;
   select * from category;
   select* from film_category;

select 
     film.replacement_cost,
     category.name,
     count(category.category_id) as Category_Count,
     avg(film.replacement_cost)  as  Avg_ReplacementCost,
     sum(film.replacement_cost)  as   Total_ReplacementCost
   from film
   left join film_category
   on film.film_id=film_category.film_id
   left join category
   on film_category.category_id=category.category_id
   group by category.name;
   
   
   ------------------- -- 5)
   select * from customer;
   select *from address;
   select * from city;
   select *from country;   
   
   select 
        customer.customer_id,
        customer.store_id,
        customer.first_name,
        customer.last_name,
        customer.active,
        address.address,
        address.district,
        city.city,
        country.country
    from customer
    left join address
    on customer.address_id=address.address_id
    left join city
    on address.city_id=city.city_id
    left join country
    on city.country_id=country.country_id;
 
 ------------------- -- 6)
 
 select * from customer;
 select * from payment;
 
 select 
      customer.customer_id,
      customer.first_name,
      customer.last_name,
      sum(payment.amount) as Total_Payment
  from customer    
  left join payment
 on customer.customer_id=payment.customer_id
 group by customer.customer_id
 order by Total_Payment desc;
 
 --------------------------------- -- 7)
 
 select * from investor;
 select * from advisor;
 
 select 
      company_name,
     concat(first_name,'    ', last_name) as Names,
     "investor" as "Investor/Advisor"
   from investor
   union
   select
        is_chairmain as Chairmain_Status,
       concat(first_name,'    ', last_name) as Names,
       "advisor" as "Investor/Advisor"
       from advisor;
 
 
 --------------------------- -- 8)
 
 
 
 